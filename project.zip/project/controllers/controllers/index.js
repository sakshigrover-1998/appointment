var express=require("express");
var bodyParser=require('body-parser');
var app = express();
var logger = require('morgan');


var authenticateController=require('./controllers/authenticate-controller');
var registerController=require('./controllers/register-controller');
const cors = require('cors');
var appointmentsRouter = require('./routes/appointments');
var usersRouter = require('./routes/users');

app.use(bodyParser.urlencoded({extended:true}));
app.use(bodyParser.json());
app.use(cors());

//app.use('/register',registerController);
//app.use('/authenticate',authenticateController);
/* route to handtration */
app.post('/api/register',registerController.register);
app.post('/api/authenticate',authenticateController.authenticate);
app.post('/api/appointments',appointmentsRouter.appointments);


//module.exports=app;
app.listen(8080)