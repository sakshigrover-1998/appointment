var connection = require('./../config');
var express=require('express');
var router=express.Router();
/*router.get("/:username",(req,res,next) => {
  res.status(200).json({
    message:" Hey!"
  });
});*/
module.exports.register=function(req,res){
    var today = new Date();
    var users={
        
        "username":req.body.username,
        "password":req.body.password,
        
        
    }
    connection.query('SElECT FROM healthplus-278304.test.login Where ?',`healthplus-278304.test.login`, function (error, results, fields) {
      if (error) {
        res.json({
            status:false,
            message:'No such user exists'
        })
      }else{
          res.json({
            status:true,
            data:results,
            message:'Registered User'
        })
      }
    });
}